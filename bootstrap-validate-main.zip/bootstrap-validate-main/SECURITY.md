# Security

## Reporting a Vulnerability

Please report (suspected) security vulnerabilities to mail@pacalebeier.de.
